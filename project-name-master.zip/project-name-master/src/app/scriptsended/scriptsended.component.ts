import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scriptsended',
  templateUrl: './scriptsended.component.html',
  styleUrls: ['./scriptsended.component.css']
})
export class ScriptsendedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
